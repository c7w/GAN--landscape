import wandb

wandb.init(project="test-project", entity="jittor-landscape")
wandb.config = {
  "learning_rate": 0.001,
  "epochs": 100,
  "batch_size": 128
}

for i in range(1, 100):
    wandb.log({"loss":i})