import IPython
import jittor as jt
import jittor.nn as nn
from models.utils.utils import start_grad, stop_grad, weights_init_normal

class NoiseInjection(jt.Module):
    def __init__(self, channel):
        self.weight = jt.zeros((1, channel, 1, 1))

    def execute(self, image, noise):
        return image + self.weight * noise