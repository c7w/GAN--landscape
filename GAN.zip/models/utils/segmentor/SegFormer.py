import jittor as jt
import jittor.nn as nn


# Reference: https://github.com/NVlabs/SegFormer
class SegFormer(nn.Module):
    def __init__(self):
        super(SegFormer, self).__init__()

    def execute(self, input):
        # return self.model(input)
        pass
