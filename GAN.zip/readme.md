# GAN!

Anonymous Author(s)

## Requirements

TODO

## Train

TODO

## 创新点
+ Try generator more if it is weak
+ Global features
+ Use Transformer

## Reference

+ StyleGAN
+ epe
+ SegFormer